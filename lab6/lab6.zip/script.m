load('energy.mat');

[country, source, degrees, y_original, y_yearly, y_approximation, mse, msek] = zadanie5(energy);