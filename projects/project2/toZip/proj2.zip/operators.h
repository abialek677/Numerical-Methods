#pragma once


#include <vector>
using namespace std;

vector<double> operator-(vector<double>& a, vector<double>& b);
vector<double> operator+(const vector<double>& a, const vector<double>& b);