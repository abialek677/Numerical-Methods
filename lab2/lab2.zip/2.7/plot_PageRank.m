function plot_PageRank(r)
bar(r)
xlabel('Page number')
ylabel('Importance')
title('Page Rank')
% print -dpng zadanie7.png 
end