function plot_counts_mean(counts_mean)

plot(counts_mean)
ylabel('Average amount')
xlabel('Circle count')
title('Average amount of times to get a proper circle')



end