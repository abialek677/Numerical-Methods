function plot_circle_areas(circle_areas)


plot(circle_areas)
ylabel('Sum of areas')
xlabel('Circle count')
title('Circle areas')

end