N = 1000:1000:8000;
n = length(N);
vtime_direct = ones(1,n); 
for i=1:n
    [~,~,~, time_help,~,~] = solve_direct(N(i));
    vtime_direct(i) = time_help;
end
plot_direct(N,vtime_direct);


time_Jacobi = ones(1,n);
time_Gauss_Seidel = 2*ones(1,n);
iterations_Jacobi = 40*ones(1,n);
iterations_Gauss_Seidel = 40*ones(1,n);
for i=1:n
    [~,~,~,~,~,~,time_j,iterations_j,~] = solve_Jacobi(N(i));
    [~,~,~,~,~,~,time_gs,iterations_gs,~] = solve_Gauss_Seidel(N(i));
    time_Jacobi(i) = time_j;
    time_Gauss_Seidel(i) = time_gs;
    iterations_Jacobi(i) = iterations_j;
    iterations_Gauss_Seidel(i) = iterations_gs;
end
plot_problem_5(N,time_Jacobi,time_Gauss_Seidel,iterations_Jacobi,iterations_Gauss_Seidel);